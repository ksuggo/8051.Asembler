#include <8051.h>
void main()
{
int flag;
unsigned char i,j;  
unsigned char massiv [11]=
{
0xC0, 
0xF9,
0xA4,
0xB0,
0x99,
0x92,
0x82,
0xF8,
0x80,
0x90,
0xFF 
};
P10 = 0;
flag = 0;
//P1=massiv [10];
while(1){ 
for(i=flag;i<10;i+=(flag+1)) 
{
if (flag != 1 && P10 == 1){
flag = 1;
break;
}

P2=massiv[i]; 
for(j=0;j<100;j++)
continue;
}
}
P2=massiv[10]; 

}